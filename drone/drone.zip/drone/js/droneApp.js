$(function()
{

    var cloudmade = L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
    });
    var map = L.map('map',{zoom: 15}).addLayer(cloudmade);
    var osmGeocoder = new L.Control.OSMGeocoder();
    map.addControl(osmGeocoder);
    map.addControl( L.control.zoom({position: 'bottomright'}) );

    var markers = new L.MarkerClusterGroup({});
/**
    var requestURL = 'http://localhost:8081/AIDRTrainerAPI/rest/drone/jsonp/getdrones';
                        $.ajax({
                                type: 'GET',
                                url: requestURL,
                                dataType: 'jsonp',
                                success: renderList,
                                error: FailedRenderList,
                                jsonp: false,
                                jsonpCallback: "jsonp"
                            });

**/
    var autoGeoRefresh = setInterval(
                function ()  // Call out to get the time
                {
                    var requestURL = 'http://gis.micromappers.org/drone/rest/web/jsonp/getdrones';
                    if(typeof indexID != 'undefined' ){
                        requestURL = 'http://gis.micromappers.org/drone/rest/web/jsonp/drones/after/' + indexID;
                    }

                    $.ajax({
                            type: 'GET',
                            url: requestURL,
                            dataType: 'jsonp',
                            success: renderList,
                            error: FailedRenderList,
                            jsonp: false,
                            jsonpCallback: "jsonp"
                        });


                }, 5000);// end check

    function renderList(data) {
        var dataCount = 0;
        $.each(data, function(i, field){
              dataCount++;
              geoDatColection.push( field );
              mapDataCollection = geoDatColection;


         });

        if(dataCount > 0){
            displayAllRow(data);
            populateMakers();
            map.addLayer(markers);
            map.fitBounds(markers.getBounds());
        }
    }

    function populateMakers(){
        for( var i in mapDataCollection){
            var item = mapDataCollection[i];
            if(!checkDuplicateEntry(item.info.url)){
                 var layName = L.geoJson(item.features, {
                    onEachFeature: function (features, layer) {
                        indexID = item.info.id;

                        layer.on("click", function (e){
                            var youtubeURL = getSelectedLayerURL(layer);
                            var vid =  youtubeURL.match(/v=([^&]+)/)[1];
                            var src = "http://www.youtube.com/embed/" + vid + "?autoplay=1&showinfo=1&controls=1";
                            $("#uavVideo").attr('src', src);
                            window.location.href='#uavOpenModal';

                        });

                        geoLayerCollection.push( new layerInfo(layer, item.info.url) ) ;
                    }
                });
                markers.addLayer(layName);
            }
        }
    }


    function FailedRenderList() {
        //console.log("failed");
    }

    function displayAllRow(data){

        $.each(data, function(i, field){

            if(!checkDuplicateEntry(field.info.url)){
                var displayTxt = '<a href="#uavOpenModal">';
                displayTxt =  displayTxt + '<p><b>'+ field.info.displayName +'</b></p>';
                displayTxt =  displayTxt + '<p>'+ field.info.created +'</p></a>';

                var hiddenURL = '<input name = "uavVideURL" id="uavVideURL" type="hidden" value = "'+ field.info.url +'"/>';
                displayTxt = displayTxt + hiddenURL;
                $( "#tweetList" ).prepend($("<li class='ui-widget-content' name='"+field.info.id+"'></li>").html(displayTxt));
                $("#tweetList li").unbind("click").click(function(evt) {
                   // console.log("clicker!!!");
                    var answer = $(evt.currentTarget).text();
                    var answer2 =$(evt.currentTarget).children('#uavVideURL');
                    var vid =  $(evt.currentTarget).children('#uavVideURL').attr('value').match(/v=([^&]+)/)[1];
                    var src = "http://www.youtube.com/embed/" + vid + "?autoplay=1&showinfo=1&controls=1";
                    $("#uavVideo").attr('src', src);
                    //var vid =  $(this).attr("uavVideURL");
                   // console.log($(evt.currentTarget));
                   // console.log(this);
                   // usersid =  $(this).attr("uavVideoID");
                });
            }


         });

    }

    $("#submit").click(function(e)
    {
        if(hasAllRequiredFields()){
            e.preventDefault();
            var email = $("input#email").val();
            var vURL = $("input#vURL").val();
            //console.log(email);
            //console.log(vURL);
            //console.log(geoInfoProperty);
           //$('#submit').text('Request has been sent. Thank you!');
           // $('input[type="submit"]').attr('disabled','disabled');
           // alert(geoInfoProperty);
           // $("#testForm").submit();

            var info = new Object();
            info.email = email;
            info.url = vURL;

            var data = new Object();
            data.features = geoInfoProperty;
            data.info = info;

            var myString = JSON.stringify(data);
           // myString = "jsonp(" + myString + ");"
           // console.log("myString: " + myString);
            var urlPost = "http://gis.micromappers.org/drone/rest/web/add";


            $.post( urlPost, myString );
            //$('#submit').text('Request has been sent. Thank you!');
            //$('#submit').attr('disabled','disabled');
            window.location.href='#close';
        }


    });

    function hasAllRequiredFields(){
        var email = $("input#email").val();
        var vURL = $("input#vURL").val();

        if( email == ""){
            return false;
        }

        if( email.length < 5){
            return false;
        }


        if( geoInfoProperty == ""){
            return false;
        }

        if( typeof geoInfoProperty == 'undefined'){
            return false;
        }

        if( vURL == ""){
            return false;
        }

        if( vURL.length < 5){
            return false;
        }

        return true;
    }

    function checkDuplicateEntry(newVideoURL){
        for( var i in geoLayerCollection){
            var layers = geoLayerCollection[i];

            if(layers.url == newVideoURL){
                return  true;
            }

        }

        return false;
    }

    function layerInfo(layer, vURL)
    {
        this.layer=layer;
        this.url = vURL;
    }

    function getSelectedLayerURL(layer){
        for( var i in geoLayerCollection){
            var item = geoLayerCollection[i];
            if(item.layer == layer){
                return item.url;
            }
        }
    }

    $("#agree").change(function() {
        if($(this).is(":checked")) {
            $("#submit").removeAttr('disabled');
        }
        else{
             $("#submit").attr('disabled','disabled');
        }
    });

});



